ng-stripe-tutorial
==================

Demo code for AngularJS and Stripe integration tutorial.

[View Demo Online](http://urish.github.io/ng-stripe-tutorial/)

Copyright (C) 2014, Uri Shaked <uri@urish.org>

### Need help?

[Rent me](http://airpair.me/urish?utm_source=expert&utm_medium=readme&utm_term=ng-stripe-tutorial&utm_content=github-readme&utm_campaign=airpairme) by the hour on [AirPair](http://www.airpair.com/book/urish), a community of developers helping developers.


### Photo credits

* 1076085000_f2c39ddd24_z.jpg [Heather Kennedy](https://www.flickr.com/photos/moria/1076085000/)
* 11947278725_979391b9a2_z.jpg [Kārlis Dambrāns](https://www.flickr.com/photos/janitors/11947278725/)
* 2705207852_2758109a1b_z.jpg [Hajime NAKANO](https://www.flickr.com/photos/jetalone/2705207852/)
* 12099351973_062cdcd1ee_z.jpg [Finn Frode](https://www.flickr.com/photos/finnfrode/12099351973)
* 283182167_5a1b5b13c1_z.jpg [megan ann](https://www.flickr.com/photos/chainsawpanda/283182167/)
* QuickCollarNeck_wb.jpg [Elf](https://en.wikipedia.org/wiki/User:Elf)

License
----

Released under the terms of MIT License:

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
'Software'), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
