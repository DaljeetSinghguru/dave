
var app = angular.module('StripeDemo', ['ui.bootstrap.stripe-form'])



app.config(function ($httpProvider) {
    Stripe.setPublishableKey('pk_test_AtwzOkhlU1GwB9VlMp0nvt2w');
});   